# LinuxStore


## Installation

Install using git:

```bash
git clone https://github.com/arjunj132/LinuxStore.git
```

Then open the directory and run the file:

```bash
cd LinuxStore
python3 store.py
```

## Usage:

Enter the project name and it should give you a result on some services to download the project.